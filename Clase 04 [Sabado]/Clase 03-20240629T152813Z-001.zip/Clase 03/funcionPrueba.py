num = int(input("Ingrese numero de asistente"))

while num:
    if num < 5:
     print("Sigue la clase")
    else:
     print("Chau")
     break